import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int decisao = 1;
        while(decisao == 1){
            System.out.println("Digite o primeiro número:");
            double num1 = sc.nextDouble();

            System.out.println("Operador:\n1 - adição\n2 - subtração" +
                    "\n3 - divisão\n4 - multiplicação\n5 - radiciação" +
                    "\n6 - Potenciação");
            int op = sc.nextInt();

            System.out.println("Digite o outro número:");
            double num2 = sc.nextDouble();

            Calculos cal = new Calculos(num1,op,num2);
            switch (op){
                case 1:
                    System.out.println(cal.adicao());
                    break;
                case 2:
                    System.out.println(cal.subtracao());
                    break;
                case 3:
                    System.out.println(cal.divisao());
                    break;
                case 4:
                    System.out.println(cal.multiplicacao());
                    break;
                case 5:
                    System.out.println(cal.radiciacao());
                    break;
                case 6:
                    System.out.println(cal.potenciacao());
                    break;
            }
            System.out.println("Deseja realizar uma nova operação?\n1 - sim\n2 - não");
            decisao = sc.nextInt();
        }

    }
}
